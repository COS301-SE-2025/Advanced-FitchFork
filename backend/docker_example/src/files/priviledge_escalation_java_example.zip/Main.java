import java.io.*;

public class Main
{
    public static void main(String[] args)
    {
        try
        {
            Process p = Runtime.getRuntime().exec("id");
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null)
            {
                System.out.println(line);
            }
        } catch (Exception e)
        {
            System.out.println("Privilege check failed: " + e.getMessage());
        }
    }
}
