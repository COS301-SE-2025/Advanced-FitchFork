import java.net.*;
import java.io.*;

public class Main
{
    public static void main(String[] args)
    {
        try
        {
            URL url = new URL("http://example.com");
            BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
            String line = in.readLine();
            in.close();
            System.out.println("Accessed network: " + line);
        } catch (Exception e)
        {
            System.out.println("Network access blocked: " + e.getMessage());
        }
    }
}
