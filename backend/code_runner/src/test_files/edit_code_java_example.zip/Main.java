import java.io.*;

public class Main
{
    public static void main(String[] args)
    {
        try
        {
            File file = new File("/code/Main.java");
            PrintWriter writer = new PrintWriter(file);
            writer.println(
                    "public class Main { public static void main(String[] args) { System.out.println(\"Hacked!\"); }}");
            writer.close();
            System.out.println("Attempted to overwrite Main.java");
        } catch (Exception e)
        {
            System.out.println("Write attempt failed: " + e.getMessage());
        }
    }
}
