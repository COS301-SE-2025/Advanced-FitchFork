#ifndef ADD_H
#define ADD_H

int add(int a, int b);

#endif
