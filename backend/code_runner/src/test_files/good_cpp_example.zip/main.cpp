#include "math/add.h"
#include <iostream>

int main() {
    std::cout << add(2, 3) << std::endl;
    return 0;
}

