
public class HelperOne {
    public static String subtaskA() {
        return "" + "HelperOne: Subtask for Task1\nThis as well\nAnd this";
    }
    public static String subtaskZ() {
        return "HelperOne: Subtask for Task2\nThis as well\nAnd this";
    }
    public static String subtaskBeta() {
        return "HelperOne: Subtask for Task3\nThis as well\nAnd this";
    }
}
