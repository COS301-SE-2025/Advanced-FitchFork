
public class HelperTwo {
    public static String subtaskB() {
        return "HelperTwo: Subtask for Task1\nThis as well\nWrong output here";
    }
    public static String subtaskX() {
        return "HelperTwo: Subtask for Task2\nThis as well\nAnd this";
    }
    public static String subtaskGamma() {
        return "";
    }
}
