
#include "HelperTwo.h"
std::string HelperTwo::subtaskB() {
    return "HelperTwo: Subtask for Task1\nThis as well\nAnd this";
}
std::string HelperTwo::subtaskX() {
    return "HelperTwo: Subtask for Task2\nThis as well\nAnd this";
}
std::string HelperTwo::subtaskGamma() {
    return "HelperTwo: Subtask for Task3\nThis as well\nAnd this";
}
