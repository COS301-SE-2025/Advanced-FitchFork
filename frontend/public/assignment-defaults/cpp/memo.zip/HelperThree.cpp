
#include "HelperThree.h"
std::string HelperThree::subtaskC() {
    return "HelperThree: Subtask for Task1\nThis as well\nAnd this";
}
std::string HelperThree::subtaskY() {
    return "HelperThree: Subtask for Task2\nThis as well\nAnd this";
}
std::string HelperThree::subtaskAlpha() {
    return "HelperThree: Subtask for Task3\nThis as well\nAnd this";
}
