
#include "HelperOne.h"
std::string HelperOne::subtaskA() {
    return "HelperOne: Subtask for Task1\nThis as well\nAnd this";
}
std::string HelperOne::subtaskZ() {
    return "HelperOne: Subtask for Task2\nThis as well\nAnd this";
}
std::string HelperOne::subtaskBeta() {
    return "HelperOne: Subtask for Task3\nThis as well\nAnd this";
}
