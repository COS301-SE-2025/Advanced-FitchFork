
#include <iostream>
#include <string>
#include "HelperOne.h"
#include "HelperTwo.h"
#include "HelperThree.h"

void runTask1() {
    std::cout << "&-=-&Task1Subtask1\n" << HelperOne::subtaskA() << std::endl;
    std::cout << "&-=-&Task1Subtask2\n" << HelperTwo::subtaskB() << std::endl;
    std::cout << "&-=-&Task1Subtask3\n" << HelperThree::subtaskC() << std::endl;
}

void runTask2() {
    std::cout << "&-=-&Task2Subtask1\n" << HelperTwo::subtaskX() << std::endl;
    std::cout << "&-=-&Task2Subtask2\n" << HelperThree::subtaskY() << std::endl;
    std::cout << "&-=-&Task2Subtask3\n" << HelperOne::subtaskZ() << std::endl;
}

void runTask3() {
    std::cout << "&-=-&Task3Subtask1\n" << HelperThree::subtaskAlpha() << std::endl;
    std::cout << "&-=-&Task3Subtask2\n" << HelperOne::subtaskBeta() << std::endl;
    std::cout << "&-=-&Task3Subtask3\n" << HelperTwo::subtaskGamma() << std::endl;
}

int main(int argc, char* argv[]) {
    std::string task = argc > 1 ? argv[1] : "task1";

    if (task == "task1") runTask1();
    else if (task == "task2") runTask2();
    else if (task == "task3") runTask3();
    else std::cout << task << " is not a valid task" << std::endl;

    return 0;
}
