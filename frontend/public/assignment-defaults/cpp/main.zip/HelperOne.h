
#ifndef HELPERONE_H
#define HELPERONE_H
#include <string>
struct HelperOne {
    static std::string subtaskA();
    static std::string subtaskZ();
    static std::string subtaskBeta();
};
#endif
