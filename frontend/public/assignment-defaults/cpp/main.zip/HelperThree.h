
#ifndef HELPERTHREE_H
#define HELPERTHREE_H
#include <string>
struct HelperThree {
    static std::string subtaskC();
    static std::string subtaskY();
    static std::string subtaskAlpha();
};
#endif
