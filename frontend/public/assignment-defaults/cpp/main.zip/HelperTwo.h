
#ifndef HELPERTWO_H
#define HELPERTWO_H
#include <string>
struct HelperTwo {
    static std::string subtaskB();
    static std::string subtaskX();
    static std::string subtaskGamma();
};
#endif
