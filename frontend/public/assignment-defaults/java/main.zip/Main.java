
public class Main {
    public static void main(String[] args) {
        String task = args.length > 0 ? args[0] : "task1";

        switch (task) {
            case "task1":
                runTask1();
                break;
            case "task2":
                runTask2();
                break;
            case "task3":
                runTask3();
                break;
            default:
                System.out.println("" + task + " is not a valid task");
        }
    }

    static void runTask1() {
        System.out.println("" + "&-=-&Task1Subtask1");
        System.out.println(HelperOne.subtaskA());
        System.out.println("&-=-&Task1Subtask2");
        System.out.println(HelperTwo.subtaskB());
        System.out.println("&-=-&Task1Subtask3");
        System.out.println(HelperThree.subtaskC());
    }

    static void runTask2() {
        System.out.println("&-=-&Task2Subtask1");
        System.out.println(HelperTwo.subtaskX());
        System.out.println("&-=-&Task2Subtask2");
        System.out.println(HelperThree.subtaskY());
        System.out.println("&-=-&Task2Subtask3");
        System.out.println(HelperOne.subtaskZ());
    }

    static void runTask3() {
        System.out.println("&-=-&Task3Subtask1");
        System.out.println(HelperThree.subtaskAlpha());
        System.out.println("&-=-&Task3Subtask2");
        System.out.println(HelperOne.subtaskBeta());
        System.out.println("&-=-&Task3Subtask3");
        System.out.println(HelperTwo.subtaskGamma());
    }
}
