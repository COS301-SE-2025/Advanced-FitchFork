
public class HelperThree {
    public static String subtaskC() {
        return "HelperThree: Subtask for Task1\nThis as well\nAnd this";
    }
    public static String subtaskY() {
        return "HelperThree: Subtask for Task2\nThis as well\nAnd this";
    }
    public static String subtaskAlpha() {
        return "HelperThree: Subtask for Task3\nThis as well\nAnd this";
    }
}
